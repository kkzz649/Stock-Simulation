function ticker = QualifiedStock;

% Created by Krystal Zhang
% Email: krystal.jn.zhang@gmail.com
% Wechat Official Account: Hello_Baby_Unicorn
% Nov. 23. 2017

[num, txt, raw]  = xlsread(strcat(pwd,'\stockticker.csv'));

%Choose stocks that have market cap over USD1 billion
ticker = {''};
for k = 1: length(raw(:, 2))
    str = raw{k, 2};
    if ('B' == str(end))
         temp1 = lower(raw{k, 1});
         ticker{end +1} = char(double(temp1));
    end
end
ticker = ticker';

